import svm_emb

domain_name = '7'
data_dir = './data_correct/Ama'
word_emb_path = './results_cllm_parameter_npmi/embedding_'+domain_name+'_.vec'
word_emb_size = 1500
use_pretrained = True

accuracy = svm_emb.perform_svm(domain_name, data_dir, word_emb_path, word_emb_size, use_pretrained)