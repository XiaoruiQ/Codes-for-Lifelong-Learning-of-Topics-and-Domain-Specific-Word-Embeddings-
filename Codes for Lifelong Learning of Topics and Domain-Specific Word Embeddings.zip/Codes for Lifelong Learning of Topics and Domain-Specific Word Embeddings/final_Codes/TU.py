from collections import Counter

def compute_TU(topics):
  TU = 0
  counter = Counter()
  for topic in topics:
    counter.update(topic)

  for topic in topics:
    TU_t = 0
    for word in topic:
      TU_t += 1 / counter[word]
    TU_t /= len(topic)
    TU += TU_t

  TU /= len(topics)

  return TU